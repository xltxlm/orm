<?php
/**
 * Created by PhpStorm.
 * User: ClownFish 187231450@qq.com
 * Date: 16-4-18
 * Time: 下午10:08
 */

return array(
    "host" => "127.0.0.1",
    "port"  => "9521",
);